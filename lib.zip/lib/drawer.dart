import 'package:flutter/material.dart';
import 'random_emojı.dart';
import 'task_page.dart';
import 'task_list_page.dart';

class CustomDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          const DrawerHeader(
            decoration: BoxDecoration(
              color: Color(0xFF7C4DFF),
            ),
            child: Text(
              'Menu',
              style: TextStyle(color: Colors.white, fontSize: 24),
            ),
          ),

          ListTile(
            title: const Text('Rastgele emoji sayfası'),
            onTap: () {
              Navigator.pop(context);
              Navigator.pushNamed(context, '/randomEmo');
            },
          ),


          ListTile(
            title: const Text('Görev Ekle'),
            onTap: () {
              Navigator.pop(context);
              Navigator.pushNamed(context, '/task');
            },
          ),
          ListTile(
            title: const Text('Görev Listesi'),
            onTap: () {
              Navigator.pop(context);
              Navigator.pushNamed(context, '/tasklist');
            },
          ),

          ListTile(
            title: const Text('Hakkımızda'),
            onTap: () {
              Navigator.pop(context);
              Navigator.pushNamed(context, '/hakkimizda');
            },
          ),

          ListTile(
            title: const Text('Çıkış Yap'),
            onTap: () {
              Navigator.pop(context);
              Navigator.pushNamed(context, '/');
            },
          ),
        ],
      ),
    );
  }
}
