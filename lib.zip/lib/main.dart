import 'package:flutter/material.dart';
import 'login_page.dart';
import 'task_page.dart';
import 'task_list_page.dart';
import 'random_emojı.dart';
import 'hakkimizda_page.dart';
void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Login',
      initialRoute: '/',
      routes: {
        '/': (context) => LoginPage(),
        '/task': (context) => TaskPage(),
        '/tasklist': (context) => TaskListPage(),
        '/randomEmo' : (context) => RandomEmoPage(),
        '/hakkimizda': (context) => HakkimizdaPage(),
      },
    );
  }
}
