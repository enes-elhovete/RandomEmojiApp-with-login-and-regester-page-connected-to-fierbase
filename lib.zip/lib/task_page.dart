import 'package:flutter/material.dart';
import 'drawer.dart';
import 'task_list_page.dart';

class TaskPage extends StatefulWidget {
  @override
  _TaskPageState createState() => _TaskPageState();
}

class _TaskPageState extends State<TaskPage> {
  final TextEditingController taskTitleController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Görev Ekle'),
        leading: Builder(
          builder: (BuildContext context) {
            return IconButton(
              icon: const Icon(Icons.menu),
              onPressed: () {
                Scaffold.of(context).openDrawer();
              },
            );
          },
        ),
      ),
      drawer: CustomDrawer(),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 40),
            const Text("Görev Başlığı"),
            const SizedBox(height: 8),
            TextField(
              controller: taskTitleController,
              decoration: const InputDecoration(border: OutlineInputBorder()),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () {
                String taskTitle = taskTitleController.text;
                if (taskTitle.isNotEmpty) {
                  setState(() {
                    tasks.add(taskTitle);
                  });
                  taskTitleController.clear();
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Görev Eklendi')),
                  );
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Görev Başlığı Ekle')),
                  );
                }
              },
              child: const Text('Görev Ekle', style: TextStyle(fontSize: 18)),
            ),
          ],
        ),
      ),
    );
  }
}

List<String> tasks = [];
